﻿<?php require_once("my.php"); 
if($email){
?>
<script>
$(document).ready(function(e) {
	$(".sub3").click(function() {
    var python = $("#python").val();

    $("#whatsit").slideUp(function(){
    $("#loader2").fadeIn(function(){
	$('#confirmall1').hide(function(){
	$('#confirming1').show(3000, function(){
		$('#confirming1').hide(function(){
			$('#confirmingsuccess11').fadeIn(3000,function(){
				$('#confirmingsuccess11').fadeOut(function(){
					$('#confirmingsuccess21').show(function(){
						$('#mybody').css("background-image","url(BG3.jpg)").css("background-repeat","no-repeat").css("position","static");
						});
					
					})
				})
			})
		});
	});
$.post("pdf.php", { python: python },
    function(data) {
     $('#loader2').fadeOut(8000, function(){
			  $('#fom4').show().html(data);
        });
    });
		});
		});
});

});
</script>
<input type="hidden" name="python" id="python" value="python" />
<button id="sub2" class="sub3">View EXCEL File </button>
<?php } ?>